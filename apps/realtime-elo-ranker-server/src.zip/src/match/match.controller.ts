import { Controller, Get, Post, Body, Param } from '@nestjs/common';
import { MatchService } from './match.service';

@Controller('api/match')
export class MatchController {
  constructor(private readonly matchService: MatchService) {}

  @Post()
  async createMatch(@Body() matchData: Partial<Match>): Promise<Match> {
    return this.matchService.create(matchData);
  }

  @Get()
  async getAllMatches(): Promise<Match[]> {
    return this.matchService.findAll();
  }

  @Get(':id')
  async getMatchById(@Param('id') id: string): Promise<Match | undefined> {
    return this.matchService.findOne(id);
  }
}
