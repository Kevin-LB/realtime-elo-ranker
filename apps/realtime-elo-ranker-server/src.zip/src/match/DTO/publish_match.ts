export class PublishMatchDTO {
    player1Id: string;
    player2Id: string;
    result: 'WINNER_PLAYER1' | 'WINNER_PLAYER2';
  }
  