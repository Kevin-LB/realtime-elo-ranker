export class MatchResultDTO {
    winnerId: string;
    loserId: string;
    winnerRank: number;
    loserRank: number;
  }
  