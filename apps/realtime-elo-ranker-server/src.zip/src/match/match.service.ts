import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';

@Injectable()
export class MatchService {
  constructor(
    @InjectRepository(Match)
    private readonly matchRepository: Repository<Match>,
  ) {}

  create(matchData: Partial<Match>): Promise<Match> {
    const match = this.matchRepository.create(matchData);
    return this.matchRepository.save(match);
  }

  findAll(): Promise<Match[]> {
    return this.matchRepository.find();
  }

  findOne(id: string): Promise<Match | undefined> {
    return this.matchRepository.findOne({ where: { id } }).then((match) => match || undefined);
  }
}
