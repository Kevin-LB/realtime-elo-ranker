export class PlayerDTO {
    id: string;
    wins: number;
    losses: number;
    rank: number;
  }
  