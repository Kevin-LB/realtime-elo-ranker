export class CreatePlayerDTO {
    id: string;
  }
  