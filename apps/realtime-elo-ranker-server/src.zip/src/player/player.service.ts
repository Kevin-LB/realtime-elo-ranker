import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Player } from './player.entity';

@Injectable()
export class PlayerService {
  constructor(
    @InjectRepository(Player)
    private readonly playerRepository: Repository<Player>,
  ) {}

  create(playerData: Partial<Player>): Promise<Player> {
    const player = this.playerRepository.create(playerData);
    return this.playerRepository.save(player);
  }

  getAllPlayers(): Promise<Player[]> {
    return this.playerRepository.find();
  }

  getPlayerById(id: string): Promise<Player | undefined> {
    return this.playerRepository.findOne({ where: { id } }).then((player) => player || undefined);
  }
}
