import { Controller, Get, Post, Body, Param } from '@nestjs/common';
import { PlayerService } from './player.service';
import { Player } from './player.entity';

@Controller('players')
export class PlayerController {
  constructor(private readonly playerService: PlayerService) {}

  @Post()
  createPlayer(@Body() playerData: Partial<Player>): Promise<Player> {
    return this.playerService.create(playerData);
  }

  @Get()
  getAllPlayers(): Promise<Player[]> {
    return this.playerService.getAllPlayers();
  }

  @Get(':id')
  getPlayerById(@Param('id') id: string): Promise<Player | undefined> {
    return this.playerService.getPlayerById(id);
  }
}
