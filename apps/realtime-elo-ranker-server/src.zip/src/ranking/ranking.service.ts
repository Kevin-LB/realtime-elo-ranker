import { Injectable } from '@nestjs/common';
import { Repository } from 'typeorm';

@Injectable()
export class RankingService {
  constructor(
    @InjectRepository(Ranking)
    private readonly rankingRepository: Repository<Ranking>,
  ) {}

  updateRanking(id: string, rank: number): Promise<Ranking> {
    return this.rankingRepository
      .findOne({ where: { id } })
      .then((ranking) => {
        if (!ranking) {
          ranking = this.rankingRepository.create({ id, rank });
        } else {
          ranking.rank = rank;
        }
        return this.rankingRepository.save(ranking);
      });
  }

  getPlayerScore(id: string): Promise<number | undefined> {
    return this.rankingRepository
      .findOne({ where: { id } })
      .then((ranking) => (ranking ? ranking.rank : undefined));
  }

  getRanking(): Promise<Ranking[]> {
    return this.rankingRepository.find({ order: { rank: 'DESC' } });
  }
}
